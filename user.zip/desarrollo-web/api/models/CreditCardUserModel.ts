export default class CreditCardUserModel {
    cc_number: string
    constructor(cc_number: string = '') {
        this.cc_number = cc_number
    }
}