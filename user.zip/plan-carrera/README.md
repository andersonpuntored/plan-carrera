# PLAN CARRERA

Este repositorio contiene las secciones 2 y 3 de la prueba tecnica

## retos
La carpeta /retos contiene las pruebas de algoritmo y programacion en js

## desarrollo web
La carpeta /desarrollo-web contiene la seccion 3: diseño de sistemas de software
