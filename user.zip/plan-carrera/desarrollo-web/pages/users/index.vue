<template>
  <GeneralUserCard></GeneralUserCard>
</template>

<script>
import GeneralUserCard from "~/component/UsersCard/GeneralUserCard.vue";

export default {
  components: {GeneralUserCard},
}
</script>